```python
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import scipy.stats as stats
import sklearn
```


```python
sample=pd.read_csv("http://bit.ly/w-data") # to read data  from url
```


```python
sample.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2.5</td>
      <td>21</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5.1</td>
      <td>47</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.2</td>
      <td>27</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8.5</td>
      <td>75</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3.5</td>
      <td>30</td>
    </tr>
  </tbody>
</table>
</div>




```python
sample.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>25.000000</td>
      <td>25.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>5.012000</td>
      <td>51.480000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2.525094</td>
      <td>25.286887</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.100000</td>
      <td>17.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2.700000</td>
      <td>30.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>4.800000</td>
      <td>47.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>7.400000</td>
      <td>75.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>9.200000</td>
      <td>95.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
from sklearn import linear_model # imorting required library files linear model
```


```python
regr= linear_model.LinearRegression() #intializing
```


```python
y=sample['Scores']
```


```python
x= sample[['Hours']]
```


```python
regr.fit(x,y)
```




    LinearRegression()




```python
regr.coef_
```




    array([9.77580339])




```python
regr.intercept_
```




    2.483673405373196




```python
r_sq = regr.score(x, y)
print('coefficient of determination:', r_sq)
```

    coefficient of determination: 0.9529481969048356
    


```python
predicted_values= regr.predict(x)
```


```python
import math
sample["predicted"]= predicted_values.round(2)
```


```python
sample.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
      <th>predicted</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2.5</td>
      <td>21</td>
      <td>26.92</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5.1</td>
      <td>47</td>
      <td>52.34</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.2</td>
      <td>27</td>
      <td>33.77</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8.5</td>
      <td>75</td>
      <td>85.58</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3.5</td>
      <td>30</td>
      <td>36.70</td>
    </tr>
  </tbody>
</table>
</div>




```python
residuals= (y-predicted_values)
```


```python
residuals
```




    0     -5.923182
    1     -5.340271
    2     -6.766244
    3    -10.578002
    4     -6.698985
    5      2.852622
    6     -4.421065
    7      3.749408
    8     -2.622842
    9     -3.878343
    10     7.242640
    11     1.839087
    12    -5.474789
    13     7.256175
    14     3.762943
    15     5.511676
    16     3.076818
    17     2.942300
    18     4.883926
    19    -5.824618
    20     1.121657
    21     4.592470
    22    -4.631726
    23     6.063283
    24     7.265060
    Name: Scores, dtype: float64




```python
plt.scatter(sample['Hours'],sample['residuals'], color= "green")
plt.xlabel('residuals')
plt.ylabel('Scores')
```




    Text(0, 0.5, 'Scores')




    
![png](output_17_1.png)
    



```python
plt.scatter(sample['Hours'],sample['Scores'], color= "blue")
plt.scatter(sample['Hours'],sample['predicted'], color= "red")
#plt.scatter(sample['Hours'],sample['residuals'], color= "green")
plt.xlabel(' Hours')
plt.ylabel('Scores')
```




    Text(0, 0.5, 'Scores')




    
![png](output_18_1.png)
    



```python
sample.corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
      <th>predicted</th>
      <th>residuals</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Hours</th>
      <td>1.000000e+00</td>
      <td>0.976191</td>
      <td>1.000000</td>
      <td>5.343895e-17</td>
    </tr>
    <tr>
      <th>Scores</th>
      <td>9.761907e-01</td>
      <td>1.000000</td>
      <td>0.976195</td>
      <td>2.169143e-01</td>
    </tr>
    <tr>
      <th>predicted</th>
      <td>1.000000e+00</td>
      <td>0.976195</td>
      <td>1.000000</td>
      <td>1.921327e-05</td>
    </tr>
    <tr>
      <th>residuals</th>
      <td>5.343895e-17</td>
      <td>0.216914</td>
      <td>0.000019</td>
      <td>1.000000e+00</td>
    </tr>
  </tbody>
</table>
</div>




```python
sample['residuals']= residuals
```


```python
#sample.drop('residuale', axis='columns', inplace=True)
```


```python
sample.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
      <th>predicted</th>
      <th>residuals</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>25.000000</td>
      <td>25.000000</td>
      <td>25.000000</td>
      <td>2.500000e+01</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>5.012000</td>
      <td>51.480000</td>
      <td>51.480000</td>
      <td>-3.694822e-15</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2.525094</td>
      <td>25.286887</td>
      <td>24.684394</td>
      <td>5.485087e+00</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.100000</td>
      <td>17.000000</td>
      <td>13.240000</td>
      <td>-1.057800e+01</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2.700000</td>
      <td>30.000000</td>
      <td>28.880000</td>
      <td>-5.340271e+00</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>4.800000</td>
      <td>47.000000</td>
      <td>49.410000</td>
      <td>1.839087e+00</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>7.400000</td>
      <td>75.000000</td>
      <td>74.820000</td>
      <td>4.592470e+00</td>
    </tr>
    <tr>
      <th>max</th>
      <td>9.200000</td>
      <td>95.000000</td>
      <td>92.420000</td>
      <td>7.265060e+00</td>
    </tr>
  </tbody>
</table>
</div>




```python
y_pred = regr.intercept_ + regr.coef_ * 9.25
print('predicted response:', y_pred, sep='\n')
```

    predicted response:
    [92.90985477]
    


```python

```
